export const metadata = { title: 'ShadowPay example store' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
	return (
		<html lang="en">
			<body style={{ fontFamily: 'system-ui, sans-serif', maxWidth: 560, margin: '48px auto', padding: 16 }}>{children}</body>
		</html>
	);
}
