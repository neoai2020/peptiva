import { CURRENCY, PRODUCTS } from '@/lib/store';
import { BuyButton } from './buy-button';

export default function Home() {
	return (
		<main>
			<h1>Example store</h1>
			<p>Test mode: no real money moves. Pay on the test page to see the order turn paid.</p>
			{PRODUCTS.map((p) => (
				<div key={p.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0', borderBottom: '1px solid #ddd' }}>
					<span>
						{p.name} — {p.price} {CURRENCY}
					</span>
					<BuyButton productId={p.id} />
				</div>
			))}
			{/* An embedded checkout mounts its payment box here. */}
			<div id="payment" style={{ marginTop: 24 }} />
		</main>
	);
}
