'use client';

import { useState } from 'react';
import { handleNextAction, type NextAction } from '@shadowpayhq/sdk/js';

export function BuyButton({ productId }: { productId: string }) {
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState<string | null>(null);

	async function buy() {
		setBusy(true);
		setError(null);
		try {
			// Only the product id goes to the server; it decides the amount.
			const res = await fetch('/api/checkout', {
				method: 'POST',
				headers: { 'content-type': 'application/json' },
				body: JSON.stringify({ productId }),
			});
			const body = (await res.json()) as { nextAction?: NextAction; error?: string };
			if (!res.ok || !body.nextAction) throw new Error(body.error ?? 'Could not start the payment');
			// Redirect types leave the page; embedded types mount into #payment.
			handleNextAction(body.nextAction, document.getElementById('payment'), {
				onSuccess: ({ checkoutId }) => { window.location.href = `/thanks?checkout_id=${checkoutId}`; },
				onFailure: () => {
					setError('The payment did not go through. Please try again.');
					setBusy(false);
				},
			});
		} catch (err) {
			setError(err instanceof Error ? err.message : 'Something went wrong');
			setBusy(false);
		}
	}

	return (
		<span>
			<button onClick={buy} disabled={busy}>{busy ? 'Opening payment…' : 'Buy'}</button>
			{error ? <small style={{ color: 'crimson', marginLeft: 8 }}>{error}</small> : null}
		</span>
	);
}
