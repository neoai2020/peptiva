import { ShadowPay, ShadowPayError } from '@shadowpayhq/sdk/server';
import { getOrder, markOrderPaid } from '@/lib/store';

const shadowpay = new ShadowPay();

/**
 * The ONLY place an order becomes paid. Set this URL (via a tunnel when local)
 * as the test webhook on your developer page.
 */
export async function POST(req: Request) {
	let event;
	try {
		// Raw body: the signature covers the exact bytes.
		event = await shadowpay.webhooks.verify(await req.text(), req.headers.get('shadowpay-signature'));
	} catch (err) {
		// A bad signature is permanent (400). Anything else — the SDK could not
		// fetch your signing secret (network, revoked key, IP not allowed) — is
		// on our side: answer 503 so ShadowPay retries the delivery.
		if (err instanceof ShadowPayError && err.code === 'invalid_signature') {
			return new Response('invalid signature', { status: 400 });
		}
		console.error('ShadowPay webhook could not be verified', err instanceof ShadowPayError ? err.code : err);
		return new Response('verification unavailable', { status: 503 });
	}

	const c = event.data.checkout;
	if (event.type === 'checkout.succeeded' && c) {
		const result = markOrderPaid({ orderId: c.orderId, eventId: event.id, amount: c.amount, currency: c.currency });
		if (result === 'paid') {
			// Fulfil here (email, shipping…). markOrderPaid returns 'paid' once per order.
		} else if (result === 'mismatch' || result === 'unknown_order') {
			// Money arrived that doesn't match an order: keep it for a human, don't fulfil.
			console.error('ShadowPay payment needs review', { result, orderId: c.orderId, paid: `${c.amount} ${c.currency}`, eventId: event.id });
		}
	}
	if ((event.type === 'checkout.failed' || event.type === 'checkout.expired') && c) {
		const order = getOrder(c.orderId);
		// Never downgrade a paid order: a late failure can't undo a success.
		if (order && order.status === 'pending') order.status = 'failed';
	}
	return new Response('ok'); // answer 2xx quickly; duplicates are fine
}
