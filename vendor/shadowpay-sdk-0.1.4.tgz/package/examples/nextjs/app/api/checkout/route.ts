import { ShadowPay, ShadowPayError } from '@shadowpayhq/sdk/server';
import { createOrder, PRODUCTS } from '@/lib/store';

const shadowpay = new ShadowPay(); // reads SHADOWPAY_SECRET_KEY

export async function POST(req: Request) {
	const { productId } = (await req.json()) as { productId?: string };
	const product = PRODUCTS.find((p) => p.id === productId);
	if (!product) return Response.json({ error: 'Unknown product' }, { status: 400 });

	// 1. Save the order first, with the amount from YOUR catalogue.
	const order = createOrder(product);

	// 2. Create the checkout for that order.
	try {
		const site = process.env.SITE_URL ?? 'http://localhost:3000';
		const checkout = await shadowpay.checkouts.create({
			orderId: order.id,
			amount: order.amount,
			currency: order.currency,
			// Redirect to the payment page. Set it explicitly: a store with several types and no default rejects an omitted type.
			checkoutType: 'external',
			returnUrl: `${site}/thanks`,
			items: [{ name: product.name, quantity: 1, unitAmount: product.price, sku: product.id }],
		});
		order.checkoutId = checkout.id;
		// 3. The browser only gets the next action — never the key or the amount logic.
		return Response.json({ nextAction: checkout.nextAction });
	} catch (err) {
		const message = err instanceof ShadowPayError ? `${err.code}: ${err.message}` : 'Payment could not be started';
		return Response.json({ error: message }, { status: 502 });
	}
}
