import { ShadowPay } from '@shadowpayhq/sdk/server';
import { getOrder } from '@/lib/store';

export const dynamic = 'force-dynamic';

const shadowpay = new ShadowPay();

export default async function Thanks({ searchParams }: { searchParams: Promise<{ checkout_id?: string }> }) {
	const { checkout_id } = await searchParams;
	// The return URL is NOT proof of payment: we show the order's own status,
	// which only the webhook changes.
	const checkout = checkout_id ? await shadowpay.checkouts.retrieve(checkout_id).catch(() => null) : null;
	const order = checkout ? getOrder(checkout.orderId) : undefined;

	return (
		<main>
			<h1>Thank you</h1>
			{!order ? (
				<p>We could not find this order.</p>
			) : order.status === 'paid' ? (
				<p>Order {order.id} is paid. 🎉</p>
			) : order.status === 'failed' ? (
				<p>The payment for order {order.id} did not go through.</p>
			) : (
				<>
					<p>Order {order.id}: payment is processing. This page refreshes on its own.</p>
					<meta httpEquiv="refresh" content="3" />
				</>
			)}
			<p><a href="/">Back to the store</a></p>
		</main>
	);
}
