# ShadowPay example store (Next.js)

A minimal store you can run in five minutes to see the whole payment flow, then
copy into your own site. It uses an in-memory order list, so restart = empty.

## Run it

1. Copy this folder out of the SDK package, then install:

   ```bash
   npm install
   npm install /path/to/shadowpay-sdk-<version>.tgz
   ```

2. Copy `.env.example` to `.env.local` and paste your **test** key
   (`sp_test_…`) from your developer page into `SHADOWPAY_SECRET_KEY`.
3. On your developer page, add `http://localhost:3000` under Checkout settings.
4. Expose the site so payment confirmations can reach it, for example
   `cloudflared tunnel --url http://localhost:3000`, and save
   `<tunnel URL>/api/shadowpay/webhook` as the **test webhook**.
5. `npm run dev`, open http://localhost:3000 and click **Buy**.
6. On the test payment page click **Pay**. You come back to `/thanks`, which
   shows "processing" until the signed webhook marks the order paid. Try
   **Decline** too if your test page offers it: the order must stay unpaid.
   (If it shows Pay alone, your provider only confirms successes; an unpaid
   order just never gets a webhook.)

## Where things live

| File | What it does |
| --- | --- |
| `app/api/checkout/route.ts` | Saves the order (amount from your catalogue), creates the checkout, returns `nextAction`. |
| `app/buy-button.tsx` | Sends only the product id, then runs `handleNextAction` (redirect, or embedded box in `#payment`). |
| `app/api/shadowpay/webhook/route.ts` | Verifies the webhook over the raw body; the only place an order becomes paid. Dedupes by event id and checks amount + currency. |
| `app/thanks/page.tsx` | Return page: shows the order's own status, never trusts the redirect. |
| `lib/store.ts` | The in-memory "database". Replace with your real orders table. |

## Going live

The example is a demo: its orders live in memory and vanish on restart. Before
real payments:

1. Replace `lib/store.ts` with your real orders table.
2. Set `SITE_URL` to your public HTTPS address.
3. Register that HTTPS domain under Checkout settings.
4. Swap the test key for the live key the store owner gives you.
5. Set an HTTPS live webhook URL: `<SITE_URL>/api/shadowpay/webhook`.

Live `external` checkouts accept EUR only today.
