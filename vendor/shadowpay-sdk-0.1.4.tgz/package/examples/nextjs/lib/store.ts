/**
 * A tiny in-memory "database" so the example runs with no setup.
 * Replace it with your real order table: everything here is lost on restart.
 */

export type Product = { id: string; name: string; price: string };
export type Order = {
	id: string;
	productId: string;
	amount: string; // decimal string, e.g. "19.99"
	currency: string; // ISO 4217
	status: 'pending' | 'paid' | 'failed';
	checkoutId: string | null;
	paidEventId: string | null;
};

export const CURRENCY = 'EUR';

export const PRODUCTS: Product[] = [
	{ id: 'tee', name: 'Example T-shirt', price: '19.99' },
	{ id: 'mug', name: 'Example mug', price: '9.50' },
];

// Kept on globalThis so Next.js hot reload in development doesn't wipe it.
const g = globalThis as unknown as { __orders?: Map<string, Order>; __events?: Set<string> };
const orders = (g.__orders ??= new Map<string, Order>());
const processedEvents = (g.__events ??= new Set<string>());

export function createOrder(product: Product): Order {
	const order: Order = {
		id: `order_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
		productId: product.id,
		amount: product.price, // always from the server-side catalogue, never from the browser
		currency: CURRENCY,
		status: 'pending',
		checkoutId: null,
		paidEventId: null,
	};
	orders.set(order.id, order);
	return order;
}

export function getOrder(id: string): Order | undefined {
	return orders.get(id);
}

export type PaidResult = 'paid' | 'already_paid' | 'mismatch' | 'unknown_order';

/**
 * Marks an order paid from a verified `checkout.succeeded` event — once.
 * In a real database do all of this in ONE transaction (unique index on the
 * event id + `UPDATE … WHERE status <> 'paid'`): check, then record, then update.
 */
export function markOrderPaid(input: { orderId: string; eventId: string; amount: string; currency: string }): PaidResult {
	const order = orders.get(input.orderId);
	if (!order) return 'unknown_order';
	// Already paid (a retry, or a second success for the same order): fulfil once.
	if (order.status === 'paid' || processedEvents.has(input.eventId)) return 'already_paid';
	// Check BEFORE recording the event, so a mismatch is never silently consumed.
	if (Number(input.amount) !== Number(order.amount) || input.currency !== order.currency) return 'mismatch';
	processedEvents.add(input.eventId);
	order.status = 'paid';
	order.paidEventId = input.eventId;
	return 'paid';
}
