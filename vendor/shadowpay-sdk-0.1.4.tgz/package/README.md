# ShadowPay SDK

Checkout SDK for custom sites. Your server creates a checkout with your secret
key; your checkout page sends the shopper on (or embeds the payment box); you
get one signed webhook when the payment is final.

Full guides, your keys and your webhook settings live in your merchant portal
under **Store → Developers**.

## Install

Download the `.tgz` from **Store → Developers**, commit it (for example under
`vendor/`), and install it as a file dependency:

```bash
npm install ./vendor/shadowpay-sdk-<version>.tgz
```

Commit your lockfile. Requires Node 20.19+ (or Bun, Deno, edge runtimes).

Your server needs one environment variable, `SHADOWPAY_SECRET_KEY` (`sp_test_…`
or `sp_live_…`). The SDK fetches your webhook signing secret with it.

## 1. Create a checkout (server)

```ts
import { ShadowPay } from '@shadowpayhq/sdk/server';

const shadowpay = new ShadowPay(); // reads SHADOWPAY_SECRET_KEY

const checkout = await shadowpay.checkouts.create(
	{
		orderId: 'order_10245',
		amount: '53.38',
		currency: 'EUR',
		// checkoutType: 'external' | 'hosted' | 'embedded' — omit to use your store's default
		returnUrl: 'https://your-store.com/thanks',
		customer: { email: 'shopper@example.com' },
	},
);
// send checkout.nextAction to your checkout page
```

`returnUrl` and `cancelUrl` must be on a domain you registered under
**Developers → Checkout settings**. One order has at most one checkout in
progress; creating it again with the same details returns that checkout. Retries
are safe: the SDK sends an idempotency key and reuses it on its own retries.

## 2. Run the next action (browser)

```ts
import { handleNextAction } from '@shadowpayhq/sdk/js';

handleNextAction(checkout.nextAction, document.getElementById('payment'), {
	onSuccess: () => showThankYou(),
	onFailure: ({ failureCode }) => showError(failureCode),
});
```

React:

```tsx
import { ShadowPayCheckout } from '@shadowpayhq/sdk/react';

<ShadowPayCheckout nextAction={checkout.nextAction} onSuccess={showThankYou} />;
```

A `redirect` action sends the shopper away and back to your `returnUrl`; a
`mount` action renders the payment box inside the element you pass.

## 3. Confirm with the webhook (server)

The webhook is the source of truth — the shopper may never come back to your
`returnUrl`. Verify the signature over the **raw** body. `verify` also rejects
events from the other mode (a test event on a live key):

```ts
// app/api/shadowpay/route.ts (Next.js App Router)
export async function POST(req: Request) {
	const event = await shadowpay.webhooks.verify(await req.text(), req.headers.get('shadowpay-signature'));
	if (event.type === 'checkout.succeeded') {
		// dedupe on event.id, check amount + currency, then mark the order paid
	}
	return new Response('ok');
}
```

Respond with a 2xx quickly. Failed deliveries are retried for about a day;
the `ShadowPay-Event-Id` header stays the same across retries.

`checkout.failed` or `checkout.expired` can still be followed by
`checkout.succeeded` for the same checkout if a late payment arrives. Fulfil on
`checkout.succeeded`, once per order. A success for an order you already
cancelled or paid means a refund is due — contact KingsGate.

## Test mode

`sp_test_…` keys never move money. Every checkout opens a test page where you
choose the outcome (succeed, decline, require authentication), and the matching
test webhook is sent to your test endpoint. If your payment provider only
confirms successes, the page offers Pay alone.

Refunds through the SDK are not available yet: `refunds.request()` returns
`not_supported`. Live `external` checkouts accept EUR only.
